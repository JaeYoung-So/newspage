package news;

public class Report {
	private int report_id;
	private int comment_id;
	private String reason;
	private int reporter_id;
	
	public int getReport_id() {
		return report_id;
	}
	public void setReport_id(int report_id) {
		this.report_id = report_id;
	}
	public int getComment_id() {
		return comment_id;
	}
	public void setComment_id(int comment_id) {
		this.comment_id = comment_id;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public int getReporter_id() {
		return reporter_id;
	}
	public void setReporter_id(int reporter_id) {
		this.reporter_id = reporter_id;
	}
	

	
}
